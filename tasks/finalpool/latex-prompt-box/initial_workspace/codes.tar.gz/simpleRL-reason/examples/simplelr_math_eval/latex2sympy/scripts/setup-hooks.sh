#!/bin/sh
cp scripts/pre-push .git/hooks/
cp scripts/pre-commit .git/hooks/